<?php require WT_PARTIALS( 'header.php' )?>

    <div class="page-width">

        <?php require WT_PARTIALS( 'home/slide.php' )?>
        <?php require WT_PARTIALS( 'home/bestseller.php' )?>
        <?php require WT_PARTIALS( 'home/brand.php' )?>
        <?php require WT_PARTIALS( 'home/latestproduct.php' )?>
        <?php require WT_PARTIALS( 'home/smallbanner.php' )?>
        <?php require WT_PARTIALS( 'home/latestpost.php' )?>

    </div> <!-- End page-width -->

<?php require WT_PARTIALS( 'footer.php' )?>

