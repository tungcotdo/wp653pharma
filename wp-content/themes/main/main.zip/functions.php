<?php
flush_rewrite_rules( false );
require_once('define/path.php');
require_once('define/post-type.php');
require_once('define/option.php');
require_once('define/menu.php');

//   echo '<pre>';
//   print_r($bestsellers);
//   echo '</pre>';
//   die();