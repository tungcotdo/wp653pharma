<?php

    echo '__page__';

?>