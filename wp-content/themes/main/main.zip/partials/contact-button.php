<ul id="ft-contact-icons" class="active contact-icons-right">
    <li class="icon-zalo">
        <a target="_blank" href="https://zalo.me/+84962998328">
            <span class="icon"></span>
            <span class="ab"><i class="fas fa-caret-left"></i> <label>Zalo: +84962998328</label></span>
        </a>
    </li>
</ul>


